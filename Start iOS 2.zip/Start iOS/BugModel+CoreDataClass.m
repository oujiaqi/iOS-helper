//
//  BugModel+CoreDataClass.m
//  Bug
//
//  Created by brodyli on 2017/9/16.
//  Copyright © 2017年 TouchTracker. All rights reserved.
//

#import "BugModel+CoreDataClass.h"

@implementation BugModel
//-(instancetype)initWithBugid:(NSString*)bugid andTitle:(NSString*)title andDescription:(NSString*)describe
//                 andSolution:(NSString*)solution andCorrectCode:(NSString*)correctCode andErrorCode:(NSString*)errorCode andCreateTime:(NSDate*)createTime{
//    self=[super init];
//    if (self) {
//        self.bugid=bugid;
//        self.title=title;
//        self.describe=describe;
//        self.solution=solution;
//        self.correctCode=correctCode;
//        self.errorCode=errorCode;
//        self.createTime=createTime;
//    }
//    return self;
//}
@end
