//
//  QADetailViewController.h
//  Start iOS
//
//  Created by PeterLocas on 2017/11/6.
//  Copyright © 2017年 stev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QADetailViewController : UIViewController

@end
