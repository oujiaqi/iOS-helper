//
//  QADetailViewController.m
//  Start iOS
//
//  Created by PeterLocas on 2017/11/6.
//  Copyright © 2017年 stev. All rights reserved.
//

#import "QADetailViewController.h"

@implementation QADetailViewController


-(void)viewDidLoad{
self.navigationItem.title = @"详情";
}

@end
