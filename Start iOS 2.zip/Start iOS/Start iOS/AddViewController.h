
#import <UIKit/UIKit.h>
@class BNRItem;
@interface AddViewController : UIViewController
@property (nonatomic, strong) BNRItem *item;
@end
